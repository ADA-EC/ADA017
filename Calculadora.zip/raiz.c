#include "calc.h"
#include<stdio.h>
#include<math.h>

double raiz(double n){
	return sqrt(n);
}
