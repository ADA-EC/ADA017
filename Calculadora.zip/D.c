#include<stdio.h>
#include"calc.h"
double D(double a, double b){
	return a/b;
}
