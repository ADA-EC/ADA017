#include <stdio.h>
#include "calc.h"

double mult(double a , double b){
	return a*b;
}
