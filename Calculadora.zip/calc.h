double Sum(double a, double b);
double D(double a, double b);
double raiz(double a);
double mult(double a, double b);
double subt(double a, double b);
