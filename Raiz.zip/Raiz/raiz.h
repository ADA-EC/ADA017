void raiz();
