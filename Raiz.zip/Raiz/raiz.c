#include "raiz.h"
#include<stdio.h>
#include<math.h>

void raiz(double n){
	printf("A raiz de %lf é: %lf\n", n, sqrt(n));
}
